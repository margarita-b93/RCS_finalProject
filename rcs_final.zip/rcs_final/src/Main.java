public class Main {
    public static void main(String[] args) {

        Person.printInfo();

        Student Margarita = new Student(); // 4. Inicializējam child klases objektu.

        Margarita.studyProgram = "RCS mācību programma"; //5. Piešķiram vērtību mainīgajam, kas ir deklarēts parent klasē.

        Margarita.studyInfo(); // 6. Main metodē referencējam parent klasē izveidoto metodi un izsaucam to mainīgajam.

    }
}