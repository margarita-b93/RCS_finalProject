public class Student extends Person {


    //3. Izveidojam child klasi un nodrošinām pārmantojamību ar extends atslēgas vārdu.


    @Override
    public void studyInfo() {
        System.out.println("===============");
        System.out.println("Programmēšanas skolas " + studyProgram + ".");
    }
    //6. Izmantojam to pašu funkciju, kas ir parent klasē Person,
    // un pievienojam anotāciju Override, lai parādītu, ka mēs pārrakstām jau izveidoto funkciju no parent klases.
}


