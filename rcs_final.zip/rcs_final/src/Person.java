import java.text.DecimalFormat;
import java.util.Scanner;

public class Person {

    public static void printInfo() {

        Scanner scan = new Scanner(System.in);

        boolean restart = false;
        //Izveidoju do-while ciklu, lai beigās lietotājam būtu izvēle turpināt vai pārtraukt programmu. Visu kodu ieskauj do-wile ciklā.

        do {
        System.out.println("Lūdzu norādiet informāciju par sevi.");

        String firstName;
        do {
            System.out.println("Jūsu vārds:");
            firstName = scan.nextLine().trim();
            if (firstName.isEmpty()) {
                System.out.println("Lauks nevar būt tukšs. Lūdzu mēģiniet vēlreiz.");
            }
        } while (firstName.isEmpty());

        String lastName;
        do {
            System.out.println("Jūsu uzvārds:");
            lastName = scan.nextLine().trim();
            if (lastName.isEmpty()) {
                System.out.println("Lauks nevar būt tukšs. Lūdzu mēģiniet vēlreiz.");
            }
        } while (lastName.isEmpty());
        //Izmantojam do-while ciklu, lai nodrošinātu, ka lietotājs nevar atstāt tukšu lauku un programma pieprasa ievadīt datus atkārtoti.


        int age = 0;
        System.out.println("Jūsu vecums:");

            while (true) {
                if (scan.hasNextInt()) {
                    age = scan.nextInt();
                    if (age > 0) {
                        break;
                    } else {
                        System.out.println("Vecums nevar būt mazāks par 0. Lūdzu ievadiet pareizu vecumu.");
                    }
                } else {
                    System.out.println("Nepareiza ievade! Lūdzu ievadiet tikai skaitli.");
                    scan.next();
                }
            }

        scan.nextLine();

        double height_m = 0;
            System.out.println("Jūsu augums (m):");

            while (true) {
                if (scan.hasNextDouble()) {
                    height_m = scan.nextDouble();
                    if (height_m > 0) {
                        break;
                    } else {
                        System.out.println("Augums nevar būt mazāks par 0. Lūdzu ievadiet pareizu augumu.");
                    }
                } else {
                    System.out.println("Nepareiza ievade! Lūdzu ievadiet tikai skaitli.");
                    scan.next();
                }
            }

            double weight_kg = 0;
            System.out.println("Jūsu svars (kg):");

            while (true) {
                if (scan.hasNextDouble()) {
                    weight_kg = scan.nextDouble();
                    if (weight_kg > 0) {
                        break;
                    } else {
                        System.out.println("Svars nevar būt mazāks par 0. Lūdzu ievadiet pareizu svaru.");
                    }
                } else {
                    System.out.println("Nepareiza ievade! Lūdzu ievadiet tikai skaitli.");
                    scan.next();
                }
            } scan.nextLine();

        System.out.println("Jūsu dzīvesvietas valsts:");
        String country;
        do {
            country = scan.nextLine().trim();
            if (country.isEmpty()) {
                System.out.println("Lauks nevar būt tukšs. Lūdzu mēģiniet vēlreiz.");
            }
        } while (country.isEmpty());

        System.out.println("Jūsu mēneša ienākumi (EUR):");
        double monthly_income = scan.nextDouble();
        scan.nextLine();

        boolean likesToProgram;
        while (true) {
            System.out.println("Vai Jums patīk programmēt? Lūdzu atbildēt 'jā' vai 'nē':");
            String input = scan.nextLine().trim().toLowerCase();
            if (input.equals("jā")) {
                likesToProgram = true;
                break;
            } else if (input.equals("nē")) {
                likesToProgram = false;
                break;
            } else {
                System.out.println("Nepareiza ievade! Lūdzu ievadīt tikai 'jā' vai 'nē'.");
            }
        }

        //--DATU IEVADES BLOKA BEIGAS--

        //APRĒĶINU BLOKA SĀKUMS. Rezultātu izvade.

        System.out.println("===============");

        System.out.println("Balstoties uz Jūsu ievadītajiem datiem: " + "\n");

        int age_days = age * 365;
        System.out.println("Jūsu vecums dienās ir: " + age_days + " dienas.");

        double height_cent = height_m * 100;
        System.out.println("Jūsu augums centimetros ir: " + height_cent + " cm.");

        double bmi = weight_kg / (height_m * height_m);
        DecimalFormat bmi_formatted = new DecimalFormat("#.##");
        System.out.print("Jūsu ķermeņa masas indekss (BMI) ir: " + bmi_formatted.format(bmi) + ". ");

        if (bmi < 18.5) {
            System.out.println("Jums ir nepietiekama ķermeņa masa.");
        } else if (bmi > 18.5 && bmi < 24.99) {
            System.out.println("Jums ir normāla ķermeņa masa.");
        } else if (bmi > 25 && bmi < 29.99) {
            System.out.println("Jums ir lieka ķermeņa masa.");
        } else {
            System.out.println("Jums ir aptaukošanās.");
        }
        ;

        //Ķermeņa masas kategorijas noteikšanai izmantoju else-if bloku.

        double annual_income = monthly_income * 12;
        System.out.println("Jūsu gada ienākumi ir: " + annual_income + " EUR/gadā.");

        if (monthly_income < 1000) {
            System.out.println("Jūsu ienākumi ir zem vidējā.");
        }

        if (country.equalsIgnoreCase(("Latvija")) || country.equalsIgnoreCase("Latvia")) {
            System.out.println("Jūs dzīvojat Latvijā. Vidējie ienākumi šeit ir aptuveni 1500 EUR mēnesī.");
        };

            System.out.println("====================");
            System.out.println("Vai vēlaties atkārtot programmu? (jā/nē)");
            String restartInput = scan.nextLine().trim().toLowerCase();
            restart = restartInput.equals("jā");
       } while (restart);

        scan.close();
    }

    //INHERITANCE SADAĻA

    public String studyProgram;
    // 1. Nodeklarējam mainīgo

    public void studyInfo () {

        System.out.println("===============");

        System.out.println("Informācija par " + studyProgram + ".");
    }
    // 2. Izveidojam funkciju, kas izvadīs informāciju par studiju programmu (mainīgā vērtība)

}